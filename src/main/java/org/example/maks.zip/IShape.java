package org.example;

// Фигура линия
public class IShape extends Shape {
    public static final int[][] SHAPE = {
            {1, 1, 1, 1}
    };

    public IShape() {
        super(SHAPE);
    }
}
