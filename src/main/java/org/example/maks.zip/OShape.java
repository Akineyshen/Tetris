package org.example;

// Фигура квадрат
public class OShape extends Shape {
    public static final int[][] SHAPE = {
            {1, 1},
            {1, 1}
    };

    public OShape() {
        super(SHAPE);
    }
}
